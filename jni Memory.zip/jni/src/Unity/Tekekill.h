//MODIFY 
//CORINGAMODZ
///@CoRingaModzYT

class TelekillPlayer {
public:
    float X;
    float Y;
    float Z;
    TelekillPlayer() : X(0), Y(0), Z(0) {}
    TelekillPlayer(float x1, float y1, float z1) : X(x1), Y(y1), Z(z1) {}
    TelekillPlayer(const TelekillPlayer &v);
    ~TelekillPlayer();
};
TelekillPlayer::TelekillPlayer(const TelekillPlayer &v) : X(v.X), Y(v.Y), Z(v.Z) {}
TelekillPlayer::~TelekillPlayer() {}



static void Transform_INTERNAL_SetPosition(void *player, TelekillPlayer inn) {
    void (*_Transform_INTERNAL_SetPosition)(void *transform, TelekillPlayer in) = (void (*)(void *, TelekillPlayer))getRealOffset(0x31B0C98);
    _Transform_INTERNAL_SetPosition(player, inn);
}

