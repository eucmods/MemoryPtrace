//MODIFY 
//CORINGAMODZ
///@CoRingaModzYT

#ifndef Memory_h
#define Memory_h

#include <vector>

#include "Ptrace.h"
using Ptrace::Memory_Status;
using Ptrace::ProcMap;


class Memory {
private:
    uintptr_t _address;
    size_t    _size;

    std::vector<uint8_t> _orig_code;
    std::vector<uint8_t> _patch_code;

public:
    Memory();
    Memory(const char *libraryName, uintptr_t address,const void *patch_code, size_t patch_size);
    ~Memory();

    bool isValid() const;


    size_t get_PatchSize() const;

    uintptr_t get_TargetAddress() const;

    bool Restore();

    bool Modify();

    std::string ToHexString();
};

#endif
