//MODIFY 
//CORINGAMODZ
///@CoRingaModzYT


#ifndef GETPID_H
#define GETPID_H

#include <sys/syscall.h>
using namespace std;
#include <string>
#include <sstream>
#include <iostream>
#include<sstream>

long AfindLibrary(const char *library) {
    char filename[0xFF] = {0},
            buffer[1024] = {0};
    FILE *fp = NULL;
    long address = 0;
    sprintf( filename, "/proc/self/maps");
    fp = fopen( filename, "rt" );
    if( fp == NULL ){
        perror("fopen");
        goto done;
    }
    while( fgets( buffer, sizeof(buffer), fp ) ) {
        if(strstr( buffer, library ) ){
            address = (long)strtoul( buffer, NULL, 16 );
            goto done;
        }
    }
    done:
    if(fp){
        fclose(fp);
    }
    return address;
}

long ClibBase;

long MemorySearchLibrary(const char* libraryName, long relativeAddr) {
    if (ClibBase == 0) {
        ClibBase = AfindLibrary(libraryName);
        if (ClibBase == 0) {
            ClibBase = 0;
        }
    }
    return ClibBase + relativeAddr;
}

# define getRealOffset(offset) MemorySearchLibrary("libil2cpp.so",offset)

////*******HOOK TEKASHI********/////
void (*AntiCrash)(void* _this);
void  _AntiCrash(void* _this){
 return false;
}
void (*RoomEP)(void* _this);
void  _RoomEP(void* _this){
 return;
}
void (*LogApplicationDetection)(void* _this);
void _LogApplicationDetection(void* _this){
return false;
}
void(*FreeFireEnterMatch)(void* _this);
void _FreeFireEnterMatch(void* _this){
    if (FreeFireEnterMatch != NULL) {
        return;
    }
    return FreeFireEnterMatch(_this);
}


/////*****Credits By CoRingaModz
////********Telegram For Contact @CoRingaModzYT
#endif
