#include <pthread.h>
#include <jni.h>
#include <stdio.h>
#include <wchar.h>
#include <src/Substrate/SubstrateHook.h>
#include "src/Unity/Quaternion.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Unity.h"
#include "src/Unity/Color.hpp"
#include "src/Unity/Rect.hpp"
#include "memory/Memory.h"
#include "memory/getpid.h"
#include "Includes/Logger.h"

#define getRealOffset(offset) MemorySearchLibrary("libil2cpp.so",offset)
#define TEKASHI(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

extern "C" {
JNIEXPORT jstring JNICALL
Java_com_turksat_menu_MLoader_Title(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("Mod Menu by Turksat • CMODs");
}

JNIEXPORT jobjectArray JNICALL
Java_com_turksat_menu_MLoader_getFeatureListttttttttt(JNIEnv *env,jobject activityObject)
{jobjectArray ret;
    const char *features[] = {
		///////////////AIM-BOT////////////////
		    "Toggle_Aim Lock",//[0]
           
            "Toggle_Boneco Branco",//[1]
            
            "Toggle_Ghost Hack",//[2]
            
			"Toggle_Wall Pedra",//[3]
			
			"Toggle_Speede hack",//[4]
			
			///"Toggle_Desable Detection",//[5]
			};
	
    int Total_Feature = (sizeof features /
                         sizeof features[0]);

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

struct Patch {
	
    Memory aimlock1;
	Memory bypassaim1;
	Memory bypassaim2;
    Memory ghosthack1;
	Memory wallpedra1;
	Memory SpeedTime1;
	Memory bonec1;

}Tekashi;

struct {
	////MODD///ADD 
	bool bonec = false;
	bool aimlock = false;
	bool ghosthack = false;
	bool wallpedra = false;
	bool SpeedTime = false;
	//bool bannedsystem = false;
	
} CM;

bool active = true;
bool launched = false;

JNIEXPORT void JNICALL
Java_com_turksat_menu_MLoader_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint Value) {
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", Value);

    switch (feature) {
	    
        case 0:
           CM.aimlock = !CM.aimlock;
			if (CM.aimlock) {
            Tekashi.aimlock1.Modify();
			Tekashi.bypassaim1.Modify();
			Tekashi.bypassaim2.Modify();
			} else {
            Tekashi.aimlock1.Restore();
			Tekashi.bypassaim1.Restore();
			Tekashi.bypassaim2.Restore();
			}
            break;
           case 1:
			CM.bonec = !CM.bonec;
			if (CM.bonec) {
            Tekashi.bonec1.Modify();
			} else {
            Tekashi.bonec1.Restore();
			}
			break;
			case 2://GHOST HACK
			CM.ghosthack = !CM.ghosthack;
			if (CM.ghosthack) {
            Tekashi.ghosthack1.Modify();
			} else {
            Tekashi.ghosthack1.Restore();
			}
			break;
			
			case 3://WALL PEDRA
			CM.wallpedra = !CM.wallpedra;
			if (CM.wallpedra) {
            Tekashi.wallpedra1.Modify();
			} else {
            Tekashi.wallpedra1.Restore();
			}
			break;
			
			case 4://SPEED TIMER
			CM.SpeedTime = !CM.SpeedTime;
			if (CM.SpeedTime){
			Tekashi.SpeedTime1.Modify();
			} else{
			Tekashi.SpeedTime1.Restore();
			}
			break;
    }
}
/*
	  if (CM.Telekill){
						void *CMODsTELE = Component_GetTransform(closestEnemy);
						Vector3 EnemyLocation = Transform_INTERNAL_GetPosition(CMODsTELE);
						Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer), TelekillPlayer(EnemyLocation.X, EnemyLocation.Y, EnemyLocation.Z - 1));
*/
void *hack_thread(void *) {
    LOGI("Loading...");
    ProcMap il2cppMap;
    do {
        il2cppMap = Ptrace::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());//1.68.1
    TEKASHI(0x1D76A24, _AntiCrash, AntiCrash); //1.68
		//*******TESTE ENTRAR PARTIDA********///
	////REMOVIDO
	
	Tekashi.aimlock1 = Memory("libil2cpp.so", 0xDEBE4C, "\x01\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	Tekashi.bypassaim1 = Memory("libil2cpp.so", 0x1EA0A80, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);///protected override void OnFixedUpdate();
	Tekashi.bypassaim2 = Memory("libil2cpp.so", 0xFC7A88, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);///protected override void OnFixedUpdate();
	///MOD ADD
	Tekashi.ghosthack1 = Memory("libil2cpp.so", 0x14A144, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);////Desatualizado
	Tekashi.wallpedra1 = Memory("libunity.so", 0xADABE8, "\x00\x00\x00\x00", 16);
	Tekashi.SpeedTime1 = Memory("libunity.so", 0x342A0C, "\x19\x10\x28\x3E", 4);
	Tekashi.bonec1 = Memory("libil2cpp.so", 0x24265BC, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    if (!launched) {
        launched = true;
        pthread_t ptid;
        pthread_create(&ptid, 0, hack_thread, 0);
    }
    return JNI_VERSION_1_6;
}
}
